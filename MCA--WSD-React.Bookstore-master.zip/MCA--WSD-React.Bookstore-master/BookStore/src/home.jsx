

export default function Home()
{
    return(
        <>
           <div class="window-home">
                <p class="content">READ</p>
                <p class="content">GROW</p>
                <p class="content">DEVELOP</p>
                <p class="promo">Stay updated with our latest releases and promotions.</p>
        </div> 
        </>
    )
}